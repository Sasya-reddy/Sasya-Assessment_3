using ApplicationForm.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace ApplicationForm.Pages
{
    public class StudentListModel : PageModel
    {
        static List<Student> students = new List<Student>()
        {
            new Student(){ StudentId = 1, Name = "Sasya", Qualification = "Btech", Skill = "C#" },
            new Student(){ StudentId = 2, Name = "Sahi", Qualification = "Mtech", Skill = "Java" }
        };

        [BindProperty]
        public Student Student { get; set; }

        public List<Student> StudentList
        {
            get { return students; }
        }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            students.Add(Student);
            return RedirectToPage();
        }
    }
}


create database Assessment_3
--------1---------
create table Subject (
    subjectId INT primary key,
    subtitle varchar(20) NOT NULL
);
create table Book (
    bookId INT primary key,
    title varchar(20) NOT NULL,
    price int NOT NULL check (price > 0),
    volume int NOT NULL check (volume > 0),
    author varchar(20) NOT NULL,
    publishDate date NOT NULL,
    subjectId int,
    foreign key (subjectId) references subject(subjectId)
);
---------1--------
INSERT INTO Subject (subjectId, subtitle) values
(1, 'Science'),
(2, 'English'),
(3, 'Maths'),
(4, 'Social'),
(5, 'Geography');
------2-------
insert into Book (bookId, title, price, volume, author, publishDate, subjectId) values
(1, 'Maths', 200, 1, 'AAA', '2022-01-15', 1),
(2, 'Science', 450, 2, 'BBB', '2022-02-20', 1),
(3, 'C#', 250, 1, 'CCC', '2022-03-10', 2),
(4, 'Java', 350, 1, 'DDD', '2022-04-12', 2),
(5, 'Python', 400, 1, 'EEE', '2022-05-23', 3),
(6, 'IOT', 550, 2, 'FFF', '2022-06-18', 3),
(7, 'AIML', 300, 1, 'GGG', '2022-07-25', 4),
(8, 'DS', 450, 1, 'HHH', '2022-08-30', 4),
(9, 'Cyber Security', 300, 1, 'III', '2022-09-05', 5),
(10, 'Human Intellegence', 350, 1, 'JJJ', '2022-10-15', 5),
(11, 'Ruby', 400, 1, 'KKK', '2022-11-20', 1),
(12, 'Chemistry', 500, 2, 'LLL', '2022-12-01', 1),
(13, 'DBMS', 250, 1, 'MMM', '2023-01-10', 2),
(14, 'Cloud', 350, 1, 'NNN', '2023-02-15', 2),
(15, 'Sql server', 300, 1, 'OOO', '2023-03-22', 3);
select * from Book
select * from Subject
--------3-----------
select * from Book
select * from Subject
select * from Book b inner join subject s on b.subjectId = s.subjectId
----------4------------
select * 
from Book
where publishDate BETWEEN '2022-01-01' AND '2023-01-01';
-------5------
select author, count(*) as numberOfBooks
from Book
group by author;
-------6----------
select s.subtitle, count(*) as numberOfBooks
from Book b
inner join Subject s on b.subjectId = s.subjectId
group by s.subtitle;
--------7-------
select count(*) AS numberOfBooks
from Book
where year(publishDate) = 2000;
------8-------
DELETE FROM Book
WHERE bookId = 1;
------11----
select *
from Book b
inner join Subject s on b.subjectId = s.subjectId
where b.price > 500 AND s.subtitle = 'Maths';
---12-----
select b.bookId, b.title, b.price, b.volume, b.author, b.publishDate, s.subtitle
from Book b
inner join Subject s on b.subjectId = s.subjectId
order by s.subtitle ASC;
----13-----
select MIN(price) as minPrice
from Book;
----14--------
select min(price) as minPrice
from Book;
---15-----


---16----
select b.*
from Book b
inner join Subject s ON b.subjectId = s.subjectId
where s.subtitle IN ('English', 'Maths', 'Science');





